# SS MART Android starter app

This is a green-and-white Android Studio starter project for SS MART.

## Included in this first version
- Grocery home screen
- Product search
- Category filters
- Add-to-cart
- Cart total
- Checkout form (demo only)

## Important
This first version is a working UI/demo. Orders are not yet sent to a live database, customer accounts are not yet enabled, and rider/admin dashboards are not yet connected. Those are the next development steps.

## Open the project
1. Install Android Studio on a computer.
2. Extract `SSMartAndroid.zip`.
3. In Android Studio choose **Open** and select the extracted `SSMartAndroid` folder.
4. Let Gradle sync finish. Use JDK 17 if Android Studio asks.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press **Run** (green triangle).
7. To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. Android Studio will show the APK location after the build completes.

## App identity
- App name: SS MART
- Package ID: com.ssmart.grocery
- Theme: green and white
- Minimum Android: Android 6.0 (API 23)

## Next step: Firebase
To connect the live backend, register an Android app in your Firebase project using package ID `com.ssmart.grocery`, download `google-services.json`, and place it in the `app/` folder. Then we can add Firebase Authentication, Firestore products/orders, admin controls, and rider assignment.
