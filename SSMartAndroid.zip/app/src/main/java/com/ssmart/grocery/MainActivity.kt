package com.ssmart.grocery

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

data class Product(val name: String, val category: String, val price: Int, val emoji: String)

class MainActivity : Activity() {
    private val green = 0xFF176B3A.toInt()
    private val pale = 0xFFF1F7F1.toInt()
    private val products = listOf(
        Product("Fresh Milk 1 L", "Dairy", 250, "🥛"),
        Product("Farm Eggs (12)", "Dairy", 360, "🥚"),
        Product("Fresh Bananas 1 kg", "Fruits", 220, "🍌"),
        Product("Red Apples 1 kg", "Fruits", 380, "🍎"),
        Product("Potatoes 1 kg", "Vegetables", 100, "🥔"),
        Product("Tomatoes 1 kg", "Vegetables", 140, "🍅"),
        Product("Basmati Rice 1 kg", "Grocery", 320, "🍚"),
        Product("Cooking Oil 1 L", "Grocery", 590, "🫒")
    )
    private val cart = linkedMapOf<Product, Int>()
    private lateinit var root: LinearLayout
    private lateinit var cartLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = 0xFF202820.toInt(), bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
    }

    private fun button(value: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = value
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(green)
            setOnClickListener { onClick() }
        }

    private fun showHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF7FAF7.toInt())
            setPadding(dp(16), dp(14), dp(16), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = text("SS MART", 26f, green, true)
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        cartLabel = text("🛒 Cart (${cart.values.sum()})", 15f, green, true)
        cartLabel.setOnClickListener { showCart() }
        header.addView(cartLabel)
        root.addView(header)
        root.addView(text("Your daily needs, delivered to your door.", 14f, 0xFF657365.toInt()))
        val search = EditText(this).apply {
            hint = "Search groceries"
            singleLine = true
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12); bottomMargin = dp(8) })
        root.addView(text("Shop by category", 19f, 0xFF202820.toInt(), true))
        val categories = listOf("All", "Fruits", "Vegetables", "Dairy", "Grocery")
        val catRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        categories.forEach { category ->
            val b = Button(this).apply {
                text = category
                isAllCaps = false
                textSize = 11f
                setOnClickListener { renderProducts(category, search.text.toString()) }
            }
            catRow.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(3) })
        }
        root.addView(catRow)
        root.addView(text("Popular products", 19f, 0xFF202820.toInt(), true))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderProducts("All", "")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderProducts("All", s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun renderProducts(category: String, query: String) {
        val scroll = root.getChildAt(root.childCount - 1) as? ScrollView ?: return
        val list = scroll.getChildAt(0) as? LinearLayout ?: return
        list.removeAllViews()
        products.filter {
            (category == "All" || it.category == category) &&
            it.name.contains(query, ignoreCase = true)
        }.forEach { product ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(text("${product.emoji}  ${product.name}", 16f, 0xFF202820.toInt(), true))
            info.addView(text("Rs. ${product.price}  •  ${product.category}", 13f, 0xFF657365.toInt()))
            card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(button("Add +") {
                cart[product] = (cart[product] ?: 0) + 1
                updateCartLabel()
                Toast.makeText(this, "${product.name} added to cart", Toast.LENGTH_SHORT).show()
            })
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun updateCartLabel() {
        cartLabel.text = "🛒 Cart (${cart.values.sum()})"
    }

    private fun showCart() {
        val items = cart.entries.toList()
        if (items.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Your cart").setMessage("Your cart is empty.")
                .setPositiveButton("Continue shopping", null).show()
            return
        }
        val total = items.sumOf { it.key.price * it.value }
        val summary = items.joinToString("\n") { "${it.key.name} × ${it.value} = Rs. ${it.key.price * it.value}" }
        AlertDialog.Builder(this)
            .setTitle("Your shopping cart")
            .setMessage("$summary\n\nTotal: Rs. $total")
            .setNegativeButton("Keep shopping", null)
            .setPositiveButton("Checkout") { _, _ -> checkout(total) }
            .show()
    }

    private fun checkout(total: Int) {
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = EditText(this).apply { hint = "Customer name" }
        val phone = EditText(this).apply { hint = "Mobile number"; inputType = 3 }
        val address = EditText(this).apply { hint = "Complete delivery address" }
        form.addView(name); form.addView(phone); form.addView(address)
        AlertDialog.Builder(this)
            .setTitle("Checkout • Rs. $total")
            .setView(form)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Place demo order") { _, _ ->
                if (name.text.isBlank() || phone.text.isBlank() || address.text.isBlank()) {
                    Toast.makeText(this, "Please fill in all details.", Toast.LENGTH_LONG).show()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Order received!")
                        .setMessage("Thank you, ${name.text}. This is a demo order. Online order saving and rider assignment will be connected in the next step.")
                        .setPositiveButton("OK", null).show()
                    cart.clear()
                    updateCartLabel()
                }
            }.show()
    }
}
